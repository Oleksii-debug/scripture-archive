import { integer, sqliteTable, text } from "drizzle-orm/sqlite-core";
export const profiles = sqliteTable("profiles", {
  userId: text("user_id").primaryKey(), email: text("email").notNull(), firstName: text("first_name").notNull(), lastName: text("last_name").notNull(), ageRange: text("age_range").notNull(), tradition: text("tradition"), church: text("church"), maritalStatus: text("marital_status"), gender: text("gender"), locale: text("locale").notNull(), sensitiveConsent: integer("sensitive_consent", { mode: "boolean" }).notNull(), createdAt: text("created_at").notNull(), updatedAt: text("updated_at").notNull(),
});
export const progress = sqliteTable("progress", { userId: text("user_id").notNull(), missionId: text("mission_id").notNull(), data: text("data").notNull(), updatedAt: text("updated_at").notNull() });
export const siteContent = sqliteTable("site_content", { key: text("key").primaryKey(), data: text("data").notNull(), updatedAt: text("updated_at").notNull(), updatedBy: text("updated_by").notNull() });
export const homeGroups = sqliteTable('home_groups', {
  id:text('id').primaryKey(), ownerUserId:text('owner_user_id').notNull(), name:text('name').notNull(),
  church:text('church'),country:text('country'),city:text('city'),description:text('description'),
  visibility:text('visibility').notNull().default('public'),rosterVisibility:text('roster_visibility').notNull().default('count'),
  memberActivityVisibility:integer('member_activity_visibility').notNull().default(0),inviteCode:text('invite_code').notNull(),
  createdAt:text('created_at').notNull(),updatedAt:text('updated_at').notNull(),
  weeklyGoal:integer('weekly_goal').notNull().default(3),catchupMode:text('catchup_mode').notNull().default('flexible'),
  marathonEnabled:integer('marathon_enabled').notNull().default(0),studyRoute:text('study_route').notNull().default('abraham'),bibleEdition:text('bible_edition').notNull().default('uk-kulish'),
});
export const homeGroupMembers = sqliteTable('home_group_members', {
  groupId:text('group_id').notNull(),userId:text('user_id').notNull(),displayName:text('display_name').notNull(),role:text('role').notNull().default('member'),publicName:integer('public_name').notNull().default(0),publicActivity:integer('public_activity').notNull().default(0),joinedAt:text('joined_at').notNull(),
});
export const marathonRegistrations = sqliteTable('group_marathon_registrations', {
  id:text('id').primaryKey(),groupId:text('group_id').notNull(),weeklyGoal:integer('weekly_goal').notNull(),catchupMode:text('catchup_mode').notNull(),cohortKey:text('cohort_key').notNull(),status:text('status').notNull().default('forming'),startDate:text('start_date'),createdAt:text('created_at').notNull(),
});
export const groupSessions = sqliteTable('group_sessions', {
  id:text('id').primaryKey(),groupId:text('group_id').notNull(),createdBy:text('created_by').notNull(),bookId:text('book_id').notNull(),chapter:integer('chapter').notNull(),chaptersCompleted:integer('chapters_completed').notNull().default(1),answersCorrect:integer('answers_correct').notNull().default(0),answersTotal:integer('answers_total').notNull().default(0),reflection:text('reflection'),participantCount:integer('participant_count'),meetingDate:text('meeting_date').notNull(),createdAt:text('created_at').notNull(),
});
export const studyMaterials = sqliteTable('study_materials', {
  id:text('id').primaryKey(),ownerUserId:text('owner_user_id').notNull(),title:text('title').notNull(),locale:text('locale').notNull(),data:text('data').notNull(),visibility:text('visibility').notNull().default('private'),createdAt:text('created_at').notNull(),updatedAt:text('updated_at').notNull(),
});
export const groupAnswers=sqliteTable('group_answers',{groupId:text('group_id').notNull(),taskId:text('task_id').notNull(),firstCorrect:integer('first_correct').notNull(),solved:integer('solved').notNull(),attempts:integer('attempts').notNull().default(1),updatedAt:text('updated_at').notNull()});
