import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  metadataBase: new URL("https://scripture-archive.com"),
  title: "Архів Писання · Scripture Archive",
  description: "Доступна тримовна біблійна читальня та навчально-дослідницькі місії.",
  icons: { icon: "/scripture-archive-logo.svg" },
  alternates: { canonical: "/" },
  openGraph: {
    type: "website",
    url: "/",
    title: "Архів Писання · Scripture Archive",
    description: "Біблійна читальня, дослідницькі завдання та домашні групи.",
    images: [{ url: "/scripture-archive-hero-v2.png", width: 1920, height: 820 }],
  },
};

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return <html lang="uk"><head><link rel="stylesheet" href="/styles.css" /></head><body>{children}</body></html>;
}
