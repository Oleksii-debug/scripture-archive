import { env } from "cloudflare:workers";
export const dynamic = "force-dynamic";
const OWNER_EMAIL = "dordiaioleksii1@gmail.com";
const AGE_RANGES = new Set(["13-17", "18-24", "25-34", "35-44", "45-54", "55-64", "65+"]);
const ALLOWED_LOCALES = new Set(["uk", "ru", "en"]);
const TRADITIONS = new Set(["orthodox", "catholic", "protestant", "prefer_not"]);
const MARITAL_STATUSES = new Set(["married", "married_children", "single", "seeking", "separated", "widowed", "prefer_not"]);
const GENDERS = new Set(["man", "woman", "prefer_not"]);
type Identity = { userId: string; email: string; fullName: string | null };
function identity(request: Request): Identity | null {
  const userId=request.headers.get("oai-authenticated-user-id"), email=request.headers.get("oai-authenticated-user-email")?.trim().toLowerCase(); if(!userId||!email)return null;
  const encoded=request.headers.get("oai-authenticated-user-full-name"); let fullName:string|null=null;
  if(encoded&&request.headers.get("oai-authenticated-user-full-name-encoding")==="percent-encoded-utf-8")try{fullName=decodeURIComponent(encoded)}catch{}
  return {userId,email,fullName};
}
function unauthorized(){return Response.json({error:"authentication_required"},{status:401})}
function clean(value:unknown,max=120){return typeof value==="string"?value.trim().slice(0,max):""}
function publicUser(id:Identity,row:Record<string,unknown>|null){return {id:id.userId,email:id.email,fullName:id.fullName,firstName:row?.first_name??"",lastName:row?.last_name??"",ageRange:row?.age_range??"",tradition:row?.tradition??"",church:row?.church??"",maritalStatus:row?.marital_status??"",gender:row?.gender??"",locale:row?.locale??"uk",profileComplete:Boolean(row),isOwner:id.email===OWNER_EMAIL}}
export async function GET(request:Request){
  const action=new URL(request.url).searchParams.get("action")??"me"; const id=identity(request); if(!id)return action==="me"?Response.json({user:null}):unauthorized();
  if(action==="reading"){const row=await env.DB!.prepare("SELECT data FROM progress WHERE user_id=? AND mission_id='READING'").bind(id.userId).first<{data:string}>();return Response.json({reading:row?JSON.parse(row.data):[]})}
  if(action==="progress"){const row=await env.DB!.prepare("SELECT data FROM progress WHERE user_id=? AND mission_id=?").bind(id.userId,"OT-AB-01").first<{data:string}>();return Response.json({progress:row?JSON.parse(row.data):null})}
  if(action==="users"){if(id.email!==OWNER_EMAIL)return Response.json({error:"forbidden"},{status:403});const rows=await env.DB!.prepare("SELECT email,first_name,last_name,age_range,locale,created_at,updated_at FROM profiles ORDER BY created_at DESC LIMIT 250").all();return Response.json({users:rows.results})}
  const row=await env.DB!.prepare("SELECT * FROM profiles WHERE user_id=?").bind(id.userId).first<Record<string,unknown>>(); return Response.json({user:publicUser(id,row)});
}
export async function POST(request:Request){return write(request)} export async function PUT(request:Request){return write(request)}
async function write(request:Request){
  const id=identity(request);if(!id)return unauthorized();const action=new URL(request.url).searchParams.get("action")??"profile";const body=await request.json().catch(()=>null) as Record<string,unknown>|null;if(!body)return Response.json({error:"invalid_json"},{status:400});
  if(action==="reading"){if(!Array.isArray(body.reading)||body.reading.length>2000)return Response.json({error:"invalid_reading"},{status:400});const reading=body.reading.filter((r):r is Record<string,unknown>=>Boolean(r)&&typeof r==="object").map(r=>({book:clean(r.book,4),chapter:Number(r.chapter),title:clean(r.title,100)})).filter(r=>/^[1-3]?[A-Z]{2,3}$/.test(r.book)&&Number.isInteger(r.chapter)&&r.chapter>0&&r.chapter<=151);await env.DB!.prepare("INSERT INTO progress (user_id,mission_id,data,updated_at) VALUES (?,'READING',?,CURRENT_TIMESTAMP) ON CONFLICT(user_id,mission_id) DO UPDATE SET data=excluded.data,updated_at=CURRENT_TIMESTAMP").bind(id.userId,JSON.stringify(reading)).run();return Response.json({ok:true})}
  if(action==="progress"){const encoded=JSON.stringify(body.progress??{});if(encoded.length>20000)return Response.json({error:"progress_too_large"},{status:413});await env.DB!.prepare("INSERT INTO progress (user_id,mission_id,data,updated_at) VALUES (?,?,?,CURRENT_TIMESTAMP) ON CONFLICT(user_id,mission_id) DO UPDATE SET data=excluded.data,updated_at=CURRENT_TIMESTAMP").bind(id.userId,"OT-AB-01",encoded).run();return Response.json({ok:true})}
  if(action!=="profile")return Response.json({error:"unknown_action"},{status:400});
  const firstName=clean(body.firstName,80),lastName=clean(body.lastName,80),ageRange=clean(body.ageRange,10),rawTradition=clean(body.tradition,40),maritalStatus=clean(body.maritalStatus,40),gender=clean(body.gender,30);if(!firstName||!lastName||!AGE_RANGES.has(ageRange)||body.acceptPrivacy!==true)return Response.json({error:"required_fields"},{status:400});
  if((rawTradition&&!TRADITIONS.has(rawTradition))||(maritalStatus&&!MARITAL_STATUSES.has(maritalStatus))||(gender&&!GENDERS.has(gender)))return Response.json({error:"invalid_profile_option"},{status:400});
  const consent=body.acceptSensitive===true, locale=ALLOWED_LOCALES.has(clean(body.locale,2))?clean(body.locale,2):"uk",tradition=consent?rawTradition||null:null,church=consent?clean(body.church,160)||null:null;
  await env.DB!.prepare("INSERT INTO profiles (user_id,email,first_name,last_name,age_range,tradition,church,marital_status,gender,locale,sensitive_consent,created_at,updated_at) VALUES (?,?,?,?,?,?,?,?,?,?,?,CURRENT_TIMESTAMP,CURRENT_TIMESTAMP) ON CONFLICT(user_id) DO UPDATE SET email=excluded.email,first_name=excluded.first_name,last_name=excluded.last_name,age_range=excluded.age_range,tradition=excluded.tradition,church=excluded.church,marital_status=excluded.marital_status,gender=excluded.gender,locale=excluded.locale,sensitive_consent=excluded.sensitive_consent,updated_at=CURRENT_TIMESTAMP").bind(id.userId,id.email,firstName,lastName,ageRange,tradition,church,maritalStatus||null,gender||null,locale,consent?1:0).run();
  const row=await env.DB!.prepare("SELECT * FROM profiles WHERE user_id=?").bind(id.userId).first<Record<string,unknown>>();return Response.json({user:publicUser(id,row)});
}
